﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.BO
{
    public class PayloadAlert
    {
        #region Node Data Property

        public const string PAYLOADALERT_DATA_TABLE = "PAYLOADALERTAlert";
        public const string PAYLOADALERT_DATA_ID = "Id";
        public const string PAYLOADALERT_DATA_DEVICEEUI = "DeviceEUI";
        public const string PAYLOADALERT_DATA_ALERTCODE = "AlertCode";
        public const string PAYLOADALERT_DATA_ALERTTYPE = "AlertType";
        public const string PAYLOADALERT_DATA_ALERTPRIORITY = "AlertPriority";
        public const string PAYLOADALERT_DATA_ALERTCOUNTER = "AlertCounter";
        public const string PAYLOADALERT_DATA_ACXL = "AcXL";
        public const string PAYLOADALERT_DATA_ACXH = "AcXH";
        public const string PAYLOADALERT_DATA_ACYL = "AcYL";
        public const string PAYLOADALERT_DATA_ACYH = "AcYH";
        public const string PAYLOADALERT_DATA_ACZL = "AcZL";
        public const string PAYLOADALERT_DATA_ACZH = "AcZH";
        public const string PAYLOADALERT_DATA_ACC1 = "Acc1";
        public const string PAYLOADALERT_DATA_ACC2 = "Acc2";
        public const string PAYLOADALERT_DATA_ACC3 = "Acc3";
        public const string PAYLOADALERT_DATA_LATITUDE = "Acc3";
        public const string PAYLOADALERT_DATA_LONGITUDE = "Acc3";

        private int intId = 0;
        private string strDeviceEUI = string.Empty;
        private string strAlertCode = string.Empty;
        private string strAlertType = string.Empty;
        private string strAlertPriority = string.Empty;
        private string strAlertCounter = string.Empty;
        private string strAcXL = string.Empty;
        private string strAcXH = string.Empty;
        private string strAcYL = string.Empty;
        private string strAcYH = string.Empty;
        private string strAcZL = string.Empty;
        private string strAcZH = string.Empty;
        private string strAcc1 = string.Empty;
        private string strAcc2 = string.Empty;
        private string strAcc3 = string.Empty;
        private string strLatitude = string.Empty;
        private string strLongitude = string.Empty;
        #endregion


        #region ---Properties---

        public int Id
        {
            get { return intId; }
            set { intId = value; }
        }

        public string DeviceEUI
        {
            get { return strDeviceEUI; }
            set { strDeviceEUI = value; }
        }

        public string AlertCode
        {
            get { return strAlertCode; }
            set { strAlertCode = value; }
        }

        public string AlertType
        {
            get { return strAlertType; }
            set { strAlertType = value; }
        }

        public string AlertPriority
        {
            get { return strAlertPriority; }
            set { strAlertPriority = value; }
        }

        public string AlertCounter
        {
            get { return strAlertCounter; }
            set { strAlertCounter = value; }
        }

        public string AcXL
        {
            get { return strAcXL; }
            set { strAcXL = value; }
        }
        public string AcXH
        {
            get { return strAcXH; }
            set { strAcXH = value; }
        }
        public string AcYL
        {
            get { return strAcYL; }
            set { strAcYL = value; }
        }
        public string AcYH
        {
            get { return strAcYH; }
            set { strAcYH = value; }
        }
        public string AcZL
        {
            get { return strAcZL; }
            set { strAcZL = value; }
        }
        public string AcZH
        {
            get { return strAcZH; }
            set { strAcZH = value; }
        }
        public string Acc1
        {
            get { return strAcc1; }
            set { strAcc1 = value; }
        }
        public string Acc2
        {
            get { return strAcc2; }
            set { strAcc2 = value; }
        }
        public string Acc3
        {
            get { return strAcc3; }
            set { strAcc3 = value; }
        }

        public string Latitude
        {
            get { return strLatitude; }
            set { strLatitude = value; }
        }

        public string Longitude
        {
            get { return strLongitude; }
            set { strLongitude = value; }
        }


        #endregion
    }
}
