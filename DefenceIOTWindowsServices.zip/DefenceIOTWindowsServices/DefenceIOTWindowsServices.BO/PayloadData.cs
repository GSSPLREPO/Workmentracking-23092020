﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.BO
{
    public class PayloadData
    {
      
      
            public int applicationID { get; set; }
            public string applicationName { get; set; }
            public string deviceName { get; set; }
            public string devEUI { get; set; }
            public string rxInfo { get; set; }
            public string txInfo { get; set; }
            public string adr { get; set; }
            public int fcnt { get; set; }
            public int fport { get; set; }
            public string data { get; set; }
            public string objects { get; set; }
            public string location { get; set; }
            public string x_data { get; set; }
            public string y_data { get; set; }
            public string n_data { get; set; }
        public DateTime Lastseen { get; set; }
        public String Batv { get; set; }
        public bool Isout { get; set; }



    }
}
