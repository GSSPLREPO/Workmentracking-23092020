﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.BO
{
    public class Payload
    {
        #region Node Data Property

        public const string PAYLOAD_DATA_TABLE = "PayloadData";
        public const string PAYLOAD_DATA_ID = "Id";
        public const string PAYLOAD_DATA_DEVICEEUI = "DeviceEUI";
        public const string PAYLOAD_DATA_GPSLOCK = "GpsLock";
        public const string PAYLOAD_DATA_SATELITECOUNT = "SateliteCount";
        public const string PAYLOAD_DATA_LATITUDE = "Latitude";
        public const string PAYLOAD_DATA_LONGITUDE = "Longitude";
        public const string PAYLOAD_DATA_ALARM = "Alarm";
        public const string PAYLOAD_DATA_BATTERY = "Battery";
        public const string PAYLOAD_DATA_PITCH = "Pitch";
        public const string PAYLOAD_DATA_ROLL = "Roll";
        public const string PAYLOAD_DATA_PAYLOAD = "payload";

        public const string PAYLOAD_DATA_YAW = "yaw";
        public const string PAYLOAD_DATA_ACAX = "acax";
        public const string PAYLOAD_DATA_ACAY = "acay";
        public const string PAYLOAD_DATA_ACAZ = "acaz";

        public const string PAYLOAD_DATA_GX = "gx";
        public const string PAYLOAD_DATA_GY = "gy";
        public const string PAYLOAD_DATA_GZ = "gz";

        public const string PAYLOAD_DATA_MX = "mx";
        public const string PAYLOAD_DATA_MY = "my";
        public const string PAYLOAD_DATA_MZ = "mz";


        public const bool PAYLOAD_DATA_Isout =false;


        private int intId = 0;
        private string strDeviceEUI = string.Empty;
        private int intGpslock = 0;
        private int intSateliteCount = 0;
        private string strLatitude = string.Empty;
        private string strLongitude = string.Empty;
        private string strAlarm = string.Empty;
        private string strBattery = string.Empty;
        private string strPitch = string.Empty;
        private string strRoll = string.Empty;
        private string stryaw = string.Empty;
        private string strpayload = string.Empty;

        private string stracax = string.Empty;
        private string stracay = string.Empty;
        private string stracaz = string.Empty;

        private string strgx = string.Empty;
        private string strgy = string.Empty;
        private string strgz = string.Empty;

        private string strmx = string.Empty;
        private string strmy = string.Empty;
        private string strmz = string.Empty;
        private bool bisout ;


        #endregion


        #region ---Properties---

        public int Id
        {
            get { return intId; }
            set { intId = value; }
        }

        public int Gpslock
        {
            get { return intGpslock; }
            set { intGpslock = value; }
        }
        public int SateliteCount
        {
            get { return intSateliteCount; }
            set { intSateliteCount = value; }
        }

        public string DeviceEUI
        {
            get { return strDeviceEUI; }
            set { strDeviceEUI = value; }
        }

        public string Latitude
        {
            get { return strLatitude; }
            set { strLatitude = value; }
        }
        public string Longitude
        {
            get { return strLongitude; }
            set { strLongitude = value; }
        }
        public string Alarm
        {
            get { return strAlarm; }
            set { strAlarm = value; }
        }
        public string Battery
        {
            get { return strBattery; }
            set { strBattery = value; }
        }
        public string Pitch
        {
            get { return strPitch; }
            set { strPitch = value; }
        }

        public string Roll
        {
            get { return strRoll; }
            set { strRoll = value; }
        }

        public string payload
        {
            get { return strpayload; }
            set { strpayload = value; }
        }
        //
        public string acax
        {
            get { return stracax; }
            set { stracax = value; }
        }

        public string acay
        {
            get { return stracay; }
            set { stracay = value; }
        }

        public string acaz
        {
            get { return stracaz; }
            set { stracaz = value; }
        }

        //
        public string gx
        {
            get { return strgx; }
            set { strgx = value; }
        }

        public string gy
        {
            get { return strgy; }
            set { strgy = value; }
        }

        public string gz
        {
            get { return strgz; }
            set { strgz = value; }
        }

        //

        public string mx
        {
            get { return strmx; }
            set { strmx = value; }
        }

        public string my
        {
            get { return strmy; }
            set { strmy = value; }
        }

        public string mz
        {
            get { return strmz; }
            set { strmz = value; }
        }

        public string yaw
        {
            get { return stryaw; }
            set { stryaw = value; }
        }


        public bool Isout
        {
            get { return bisout; }
            set { bisout = value; }
        }


        #endregion

    }
}
