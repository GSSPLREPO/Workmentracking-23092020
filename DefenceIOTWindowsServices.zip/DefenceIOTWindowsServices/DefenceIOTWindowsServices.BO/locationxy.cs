﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.BO
{
   public class locationxy
    {
        public string devicename { get; set; }
        public string deveui { get; set; }
        public string  xdata { get; set; }
        public string ydata { get; set; }
        public string ndata { get; set; }
        public DateTime logdate { get; set; }
        public string IsPayload { get; set; }

    }
}
