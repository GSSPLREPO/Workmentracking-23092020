﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.BO
{
    public class gatwaymeta
    {
        public string DeviceName { get; set; }
        public string DeviceMac { get; set; }
        public string gateway_name { get; set; }
        public string gateway_mac { get; set; }
        public string rssi { get; set; }
        public string snr { get; set; }
        public bool alert { get; set; }
        public DateTime logdate { get; set; }

    }
}
