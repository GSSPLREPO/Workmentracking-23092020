﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DefenceIOTWindowsServices.BO;
using System.Data.SqlClient;
using DefenceIOTWindowsServices.Common;
using System.Data;
using DefenceIOTWindowsServices.DataAccess;

namespace DefenceIOTWindowsServices.BL
{
    public class TagDataInsertBL
    {


        #region user defined variables

        public string sSql;

        public string strStoredProcName;
        public SqlParameter[] pSqlParameter = null;
        #endregion

        #region Insert Payload  Details
        /// <summary>
        /// To Insert details of Payload
        /// Created By : Kuldeep
        /// Modified By :
        /// </summary>
        /// <param name="objBranchBO"></param>
        /// <returns></returns>
        public ApplicationResult PayloadData_Insert(Payload objMachineDataBO)
        {
            try
            {
                pSqlParameter = new SqlParameter[21];


                pSqlParameter[0] = new SqlParameter("@DeviceEUI", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value = objMachineDataBO.DeviceEUI;

                pSqlParameter[1] = new SqlParameter("@GpsLock", SqlDbType.Int);
                pSqlParameter[1].Direction = ParameterDirection.Input;
                pSqlParameter[1].Value = objMachineDataBO.Gpslock;

                pSqlParameter[2] = new SqlParameter("@SateliteCount", SqlDbType.Int);
                pSqlParameter[2].Direction = ParameterDirection.Input;
                pSqlParameter[2].Value = objMachineDataBO.SateliteCount;

                pSqlParameter[3] = new SqlParameter("@Latitude", SqlDbType.VarChar);
                pSqlParameter[3].Direction = ParameterDirection.Input;
                pSqlParameter[3].Value = objMachineDataBO.Latitude;

                pSqlParameter[4] = new SqlParameter("@Longitude", SqlDbType.VarChar);
                pSqlParameter[4].Direction = ParameterDirection.Input;
                pSqlParameter[4].Value = objMachineDataBO.Longitude;

                pSqlParameter[5] = new SqlParameter("@Alarm", SqlDbType.VarChar);
                pSqlParameter[5].Direction = ParameterDirection.Input;
                pSqlParameter[5].Value = objMachineDataBO.Alarm;

                pSqlParameter[6] = new SqlParameter("@Battery", SqlDbType.VarChar);
                pSqlParameter[6].Direction = ParameterDirection.Input;
                pSqlParameter[6].Value = objMachineDataBO.Battery;

                pSqlParameter[7] = new SqlParameter("@Pitch", SqlDbType.VarChar);
                pSqlParameter[7].Direction = ParameterDirection.Input;
                pSqlParameter[7].Value = objMachineDataBO.Pitch;

                pSqlParameter[8] = new SqlParameter("@Roll", SqlDbType.VarChar);
                pSqlParameter[8].Direction = ParameterDirection.Input;
                pSqlParameter[8].Value = objMachineDataBO.Roll;

                pSqlParameter[9] = new SqlParameter("@payload", SqlDbType.VarChar);
                pSqlParameter[9].Direction = ParameterDirection.Input;
                pSqlParameter[9].Value = objMachineDataBO.payload;

                //11/09/2019 update by kuldeep
                pSqlParameter[10] = new SqlParameter("@acax", SqlDbType.VarChar);
                pSqlParameter[10].Direction = ParameterDirection.Input;
                pSqlParameter[10].Value = objMachineDataBO.acax;

                pSqlParameter[11] = new SqlParameter("@acay", SqlDbType.VarChar);
                pSqlParameter[11].Direction = ParameterDirection.Input;
                pSqlParameter[11].Value = objMachineDataBO.acay;

                pSqlParameter[12] = new SqlParameter("@acaz", SqlDbType.VarChar);
                pSqlParameter[12].Direction = ParameterDirection.Input;
                pSqlParameter[12].Value = objMachineDataBO.acaz;

                //
                pSqlParameter[13] = new SqlParameter("@acgx", SqlDbType.VarChar);
                pSqlParameter[13].Direction = ParameterDirection.Input;
                pSqlParameter[13].Value = objMachineDataBO.gx;

                pSqlParameter[14] = new SqlParameter("@acgy", SqlDbType.VarChar);
                pSqlParameter[14].Direction = ParameterDirection.Input;
                pSqlParameter[14].Value = objMachineDataBO.gy;

                pSqlParameter[15] = new SqlParameter("@acgz", SqlDbType.VarChar);
                pSqlParameter[15].Direction = ParameterDirection.Input;
                pSqlParameter[15].Value = objMachineDataBO.gz;

                //
                pSqlParameter[16] = new SqlParameter("@acmx", SqlDbType.VarChar);
                pSqlParameter[16].Direction = ParameterDirection.Input;
                pSqlParameter[16].Value = objMachineDataBO.mx;

                pSqlParameter[17] = new SqlParameter("@acmy", SqlDbType.VarChar);
                pSqlParameter[17].Direction = ParameterDirection.Input;
                pSqlParameter[17].Value = objMachineDataBO.my;

                pSqlParameter[18] = new SqlParameter("@acmz", SqlDbType.VarChar);
                pSqlParameter[18].Direction = ParameterDirection.Input;
                pSqlParameter[18].Value = objMachineDataBO.mz;

                pSqlParameter[19] = new SqlParameter("@yaw", SqlDbType.VarChar);
                pSqlParameter[19].Direction = ParameterDirection.Input;
                pSqlParameter[19].Value = objMachineDataBO.yaw;

                pSqlParameter[20] = new SqlParameter("@Isout", SqlDbType.Bit);
                pSqlParameter[20].Direction = ParameterDirection.Input;
                pSqlParameter[20].Value = objMachineDataBO.Isout;



                sSql = "Usp_PayloadData_Insert";
                int iResult = Database.ExecuteNonQuery(CommandType.StoredProcedure, sSql, pSqlParameter);

                if (iResult > 0)
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.SUCCESS;
                    return objResults;
                }
                else
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.FAILURE;
                    return objResults;
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                objMachineDataBO = null;
            }
        }
        #endregion



        #region Insert Payload Alert  Details
        /// <summary>
        /// To Insert details of Payload alert
        /// Created By : Kuldeep
        /// Modified By :
        /// </summary>
        /// <param name="objBranchBO"></param>
        /// <returns></returns>
        public ApplicationResult PayloadAlert_Insert(PayloadAlert objMachineDataBO)
        {
            try
            {
                pSqlParameter = new SqlParameter[16];


                pSqlParameter[0] = new SqlParameter("@DeviceEUI", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value = objMachineDataBO.DeviceEUI;

                pSqlParameter[1] = new SqlParameter("@AlertCode", SqlDbType.VarChar);
                pSqlParameter[1].Direction = ParameterDirection.Input;
                pSqlParameter[1].Value = objMachineDataBO.AlertCode;

                pSqlParameter[2] = new SqlParameter("@AlertType", SqlDbType.VarChar);
                pSqlParameter[2].Direction = ParameterDirection.Input;
                pSqlParameter[2].Value = objMachineDataBO.AlertType;

                pSqlParameter[3] = new SqlParameter("@AlertPriority", SqlDbType.VarChar);
                pSqlParameter[3].Direction = ParameterDirection.Input;
                pSqlParameter[3].Value = objMachineDataBO.AlertPriority;

                pSqlParameter[4] = new SqlParameter("@AlertCounter", SqlDbType.VarChar);
                pSqlParameter[4].Direction = ParameterDirection.Input;
                pSqlParameter[4].Value = objMachineDataBO.AlertCounter;

                pSqlParameter[5] = new SqlParameter("@AcXL", SqlDbType.VarChar);
                pSqlParameter[5].Direction = ParameterDirection.Input;
                pSqlParameter[5].Value = objMachineDataBO.AcXL;

                pSqlParameter[6] = new SqlParameter("@AcXH", SqlDbType.VarChar);
                pSqlParameter[6].Direction = ParameterDirection.Input;
                pSqlParameter[6].Value = objMachineDataBO.AcXH;

                pSqlParameter[7] = new SqlParameter("@AcYL", SqlDbType.VarChar);
                pSqlParameter[7].Direction = ParameterDirection.Input;
                pSqlParameter[7].Value = objMachineDataBO.AcYL;

                pSqlParameter[8] = new SqlParameter("@AcYH", SqlDbType.VarChar);
                pSqlParameter[8].Direction = ParameterDirection.Input;
                pSqlParameter[8].Value = objMachineDataBO.AcYH;

                pSqlParameter[9] = new SqlParameter("@AcZL", SqlDbType.VarChar);
                pSqlParameter[9].Direction = ParameterDirection.Input;
                pSqlParameter[9].Value = objMachineDataBO.AcZL;

                pSqlParameter[10] = new SqlParameter("@AcZH", SqlDbType.VarChar);
                pSqlParameter[10].Direction = ParameterDirection.Input;
                pSqlParameter[10].Value = objMachineDataBO.AcZH;

                pSqlParameter[11] = new SqlParameter("@Acc1", SqlDbType.VarChar);
                pSqlParameter[11].Direction = ParameterDirection.Input;
                pSqlParameter[11].Value = objMachineDataBO.Acc1;

                pSqlParameter[12] = new SqlParameter("@Acc2", SqlDbType.VarChar);
                pSqlParameter[12].Direction = ParameterDirection.Input;
                pSqlParameter[12].Value = objMachineDataBO.Acc2;

                pSqlParameter[13] = new SqlParameter("@Acc3", SqlDbType.VarChar);
                pSqlParameter[13].Direction = ParameterDirection.Input;
                pSqlParameter[13].Value = objMachineDataBO.Acc3;

                pSqlParameter[14] = new SqlParameter("@Latitude", SqlDbType.VarChar);
                pSqlParameter[14].Direction = ParameterDirection.Input;
                pSqlParameter[14].Value = objMachineDataBO.Latitude;

                pSqlParameter[15] = new SqlParameter("@Longitude", SqlDbType.VarChar);
                pSqlParameter[15].Direction = ParameterDirection.Input;
                pSqlParameter[15].Value = objMachineDataBO.Longitude;



                sSql = "Usp_PayloadAlert_Insert";
                int iResult = Database.ExecuteNonQuery(CommandType.StoredProcedure, sSql, pSqlParameter);

                if (iResult > 0)
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.SUCCESS;
                    return objResults;
                }
                else
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.FAILURE;
                    return objResults;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                objMachineDataBO = null;
            }
        }
        #endregion



        #region Insert Payload data  Details
        /// <summary>
        /// To Insert details of Payload alert
        /// Created By : Kuldeep
        /// Modified By :
        /// </summary>
        /// <param name="objBranchBO"></param>
        /// <returns></returns>
        [Obsolete]
        public ApplicationResult Payload_Insert(PayloadData objMachineDataBO)
        {
            try
            {
                pSqlParameter = new SqlParameter[17];


                pSqlParameter[0] = new SqlParameter("@ApplicationId", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value = objMachineDataBO.applicationID;

                pSqlParameter[1] = new SqlParameter("@ApplicationName", SqlDbType.VarChar);
                pSqlParameter[1].Direction = ParameterDirection.Input;
                pSqlParameter[1].Value = objMachineDataBO.applicationName;

                pSqlParameter[2] = new SqlParameter("@DeviceName", SqlDbType.VarChar);
                pSqlParameter[2].Direction = ParameterDirection.Input;
                pSqlParameter[2].Value = objMachineDataBO.deviceName;

                pSqlParameter[3] = new SqlParameter("@DeviceEUI", SqlDbType.VarChar);
                pSqlParameter[3].Direction = ParameterDirection.Input;
                pSqlParameter[3].Value = objMachineDataBO.devEUI;

                pSqlParameter[4] = new SqlParameter("@RxInfo", SqlDbType.VarChar);
                pSqlParameter[4].Direction = ParameterDirection.Input;
                pSqlParameter[4].Value = objMachineDataBO.rxInfo;

                pSqlParameter[5] = new SqlParameter("@Adr", SqlDbType.VarChar);
                pSqlParameter[5].Direction = ParameterDirection.Input;
                pSqlParameter[5].Value = objMachineDataBO.adr;

                pSqlParameter[6] = new SqlParameter("@Fcnt", SqlDbType.Int);
                pSqlParameter[6].Direction = ParameterDirection.Input;
                pSqlParameter[6].Value = objMachineDataBO.fcnt;

                pSqlParameter[7] = new SqlParameter("@Fport", SqlDbType.Int);
                pSqlParameter[7].Direction = ParameterDirection.Input;
                pSqlParameter[7].Value = objMachineDataBO.fport;

                pSqlParameter[8] = new SqlParameter("@data", SqlDbType.VarChar);
                pSqlParameter[8].Direction = ParameterDirection.Input;
                pSqlParameter[8].Value = objMachineDataBO.data;

                pSqlParameter[9] = new SqlParameter("@TxInfo", SqlDbType.VarChar);
                pSqlParameter[9].Direction = ParameterDirection.Input;
                pSqlParameter[9].Value = objMachineDataBO.txInfo;

                pSqlParameter[10] = new SqlParameter("@Object", SqlDbType.VarChar);
                pSqlParameter[10].Direction = ParameterDirection.Input;
                pSqlParameter[10].Value = objMachineDataBO.objects;

                pSqlParameter[11] = new SqlParameter("@x_data", SqlDbType.VarChar);
                pSqlParameter[11].Direction = ParameterDirection.Input;
                pSqlParameter[11].Value = objMachineDataBO.x_data;

                pSqlParameter[12] = new SqlParameter("@y_data", SqlDbType.VarChar);
                pSqlParameter[12].Direction = ParameterDirection.Input;
                pSqlParameter[12].Value = objMachineDataBO.y_data;

                pSqlParameter[13] = new SqlParameter("@n_data", SqlDbType.VarChar);
                pSqlParameter[13].Direction = ParameterDirection.Input;
                pSqlParameter[13].Value = objMachineDataBO.n_data;


                pSqlParameter[14] = new SqlParameter("@location", SqlDbType.VarChar);
                pSqlParameter[14].Direction = ParameterDirection.Input;
                pSqlParameter[14].Value = objMachineDataBO.location;


                pSqlParameter[14] = new SqlParameter("@location", SqlDbType.VarChar);
                pSqlParameter[14].Direction = ParameterDirection.Input;
                pSqlParameter[14].Value = objMachineDataBO.location;


                pSqlParameter[15] = new SqlParameter("@LastSeen", SqlDbType.DateTime);
                pSqlParameter[15].Direction = ParameterDirection.Input;
                pSqlParameter[15].Value = objMachineDataBO.Lastseen;

                pSqlParameter[16] = new SqlParameter("@Batv", SqlDbType.VarChar);
                pSqlParameter[16].Direction = ParameterDirection.Input;
                pSqlParameter[16].Value = objMachineDataBO.Batv;




                sSql = "Usp_Payload_Insert";
                int iResult = Database.ExecuteNonQuery(CommandType.StoredProcedure, sSql, pSqlParameter);

                if (iResult > 0)
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.SUCCESS;
                    return objResults;
                }
                else
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.FAILURE;
                    return objResults;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                objMachineDataBO = null;
            }
        }
        #endregion




        #region Insert location xy  
        /// <summary>
        /// To Insert details of Payload alert
        /// Created By : Kuldeep
        /// Modified By :
        /// </summary>
        /// <param name="objBranchBO"></param>
        /// <returns></returns>
        [Obsolete]
        public ApplicationResult locationxy_Insert(locationxy objMachineDataBO)
        {
            try
            {
                pSqlParameter = new SqlParameter[7];


                pSqlParameter[0] = new SqlParameter("@DeviceName", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value = objMachineDataBO.devicename;

                pSqlParameter[1] = new SqlParameter("@DeviceEUI", SqlDbType.VarChar);
                pSqlParameter[1].Direction = ParameterDirection.Input;
                pSqlParameter[1].Value = objMachineDataBO.deveui;

                pSqlParameter[2] = new SqlParameter("@x_data", SqlDbType.VarChar);
                pSqlParameter[2].Direction = ParameterDirection.Input;
                pSqlParameter[2].Value = objMachineDataBO.xdata;

                pSqlParameter[3] = new SqlParameter("@y_data", SqlDbType.VarChar);
                pSqlParameter[3].Direction = ParameterDirection.Input;
                pSqlParameter[3].Value = objMachineDataBO.ydata;

                pSqlParameter[4] = new SqlParameter("@n_data", SqlDbType.VarChar);
                pSqlParameter[4].Direction = ParameterDirection.Input;
                pSqlParameter[4].Value = objMachineDataBO.ndata;

                pSqlParameter[5] = new SqlParameter("@logdate", SqlDbType.DateTime);
                pSqlParameter[5].Direction = ParameterDirection.Input;
                pSqlParameter[5].Value = objMachineDataBO.logdate;

                pSqlParameter[6] = new SqlParameter("@Ispayload", SqlDbType.VarChar);
                pSqlParameter[6].Direction = ParameterDirection.Input;
                pSqlParameter[6].Value = objMachineDataBO.IsPayload;







                sSql = "Usp_locationxy_Insert";
                int iResult = Database.ExecuteNonQuery(CommandType.StoredProcedure, sSql, pSqlParameter);

                if (iResult > 0)
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.SUCCESS;
                    return objResults;
                }
                else
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.FAILURE;
                    return objResults;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                objMachineDataBO = null;
            }
        }
        #endregion




        #region Insert location xy  
        /// <summary>
        /// To Insert details of Payload alert
        /// Created By : Kuldeep
        /// Modified By :
        /// </summary>
        /// <param name="objBranchBO"></param>
        /// <returns></returns>
        public ApplicationResult gatewaymeta_Insert(gatwaymeta objMachineDataBO)
        {
            try
            {
                pSqlParameter = new SqlParameter[8];


                pSqlParameter[0] = new SqlParameter("@DeviceName", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value = objMachineDataBO.DeviceName;

                pSqlParameter[1] = new SqlParameter("@DeviceEUI", SqlDbType.VarChar);
                pSqlParameter[1].Direction = ParameterDirection.Input;
                pSqlParameter[1].Value = objMachineDataBO.DeviceMac;

                pSqlParameter[2] = new SqlParameter("@gateway_name", SqlDbType.VarChar);
                pSqlParameter[2].Direction = ParameterDirection.Input;
                pSqlParameter[2].Value = objMachineDataBO.gateway_name;

                pSqlParameter[3] = new SqlParameter("@gateway_mac", SqlDbType.VarChar);
                pSqlParameter[3].Direction = ParameterDirection.Input;
                pSqlParameter[3].Value = objMachineDataBO.gateway_mac;

                pSqlParameter[4] = new SqlParameter("@rssi", SqlDbType.VarChar);
                pSqlParameter[4].Direction = ParameterDirection.Input;
                pSqlParameter[4].Value = objMachineDataBO.rssi;

                pSqlParameter[5] = new SqlParameter("@snr", SqlDbType.VarChar);
                pSqlParameter[5].Direction = ParameterDirection.Input;
                pSqlParameter[5].Value = objMachineDataBO.snr;

                pSqlParameter[6] = new SqlParameter("@alert", SqlDbType.VarChar);
                pSqlParameter[6].Direction = ParameterDirection.Input;
                pSqlParameter[6].Value = objMachineDataBO.alert;

                pSqlParameter[7] = new SqlParameter("@logdate", SqlDbType.DateTime);
                pSqlParameter[7].Direction = ParameterDirection.Input;
                pSqlParameter[7].Value = objMachineDataBO.logdate;







                sSql = "Usp_gateway_Insert";
                int iResult = Database.ExecuteNonQuery(CommandType.StoredProcedure, sSql, pSqlParameter);

                if (iResult > 0)
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.SUCCESS;
                    return objResults;
                }
                else
                {
                    ApplicationResult objResults = new ApplicationResult();
                    objResults.status = ApplicationResult.CommonStatusType.FAILURE;
                    return objResults;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                objMachineDataBO = null;
            }
        }
        #endregion


        #region Check Tag
        public  bool CheckTagByEUI(string EUI)
        {
            try
            {
                sSql = "Usp_GetTagStatusByEui";
                pSqlParameter = new SqlParameter[1];
                pSqlParameter[0] = new SqlParameter("@EUI", SqlDbType.VarChar);
                pSqlParameter[0].Direction = ParameterDirection.Input;
                pSqlParameter[0].Value =EUI;

                var result = Database.ExecuteScalar(CommandType.StoredProcedure,sSql, pSqlParameter);
                if (Convert.ToInt32(result)==1)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return false;
        }
        #endregion
    }
}
