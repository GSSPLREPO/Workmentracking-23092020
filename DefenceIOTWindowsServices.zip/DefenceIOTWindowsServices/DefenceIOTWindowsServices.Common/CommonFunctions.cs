﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace DefenceIOTWindowsServices.Common
{
    /// <summary>
    /// Summary description for CommonFunctions.
    /// </summary>
    public class CommonFunctions
    {

        #region constants
        /// <summary>
        /// stores the size of a single page of grid
        /// </summary>
        public const int GRID_PAGESIZE = 10;

        //changing the culture setting in the web.config will require the changes here.
        /// <summary>
        /// date format
        /// </summary>
        // public const string DATE_PARSE_FORMAT = "dd/MM/yyyy HH:mm:ss";
        public const string DATE_PARSE_FORMAT = "dd/MM/yyyy";

        //mention the null value of a date. It is use to compare the null date. It should have the format of DATE_PARSE_FORMAT const
        /// <summary>
        /// mention the null value of a date. It is use to compare the null date. It should have the format of DATE_PARSE_FORMAT const
        /// </summary>
        public const string DATE_NULL_VALE = "01/01/0001";


        //use this format to display the date in the system
        /// <summary>
        /// use this format to display the date in the system
        /// </summary>
        public const string DATE_FORMAT = "dd/MM/yy HH:mm";

        //mention the date seperator here in the display the date
        /// <summary>
        /// mention the date seperator here in the display the date
        /// </summary>
        public const string DATE_SEPERATOR = "/"; //For Display

        //mention the date format to display in the textbox attach with the calendar control
        /// <summary>
        /// mention the date format to display in the textbox attach with the calendar control
        /// </summary>
        public const string DATE_CALENDAR_FORMAT = "dd/MM/yyyy";
        //public const string DATE_CALENDAR_FORMAT = "dd/MM/yy HH:mm";

        //Setting this parameter will derive the year (e.g. year >= 70?year+1970:year+2000)
        public const bool DERIVE_YEAR = true;

        #endregion

        #region variables

        /// <summary>
        /// a Random class for generating random numbers
        /// </summary>
        public static Random mobjRandom = new Random((int)DateTime.Now.Ticks);
        #endregion

        #region FormatDate
        /// <summary>
        /// returns a datetime object by parsing the given string according to common datetime format
        /// </summary>
        /// <param name="strDate"></param>
        /// <returns></returns>
        public DateTime FormatDate(string strDate)
        {
            return FormatDate(strDate, DATE_PARSE_FORMAT);
        }

        /// <summary>
        /// returns a datetime object by parsing the given string according to common datetime format
        /// </summary>
        /// <param name="strDate"></param>
        /// <param name="strShortDatePattern"></param>
        /// <returns></returns>
        public DateTime FormatDate(string strDate, string strShortDatePattern)
        {
            try
            {
                //DateTime dtCurrentDate = DateTime.ParseExact(strDate.Split(" ".ToCharArray())[0] ,strShortDatePattern,null);
                DateTime dtCurrentDate = DateTime.ParseExact(strDate, strShortDatePattern, null);
                //return dtCurrentDate.Date;
                return dtCurrentDate;
            }
            catch
            {
                return new DateTime(0);
            }
        }
        #endregion

        #region DisplayDate
        /// <summary>
        /// Function use to display the date
        /// </summary>
        /// <param name="strDate"></param>
        /// <returns></returns>
        public string DisplayDate(string strDate)
        {
            if (strDate != null)
                //return DisplayDate(FormatDate(strDate,CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern));
                return DisplayDate(FormatDate(strDate, DATE_PARSE_FORMAT));
            else
                return "";
        }

        /// <summary>
        /// formats given datetime according to common date format
        /// </summary>
        /// <param name="dtDate"></param>
        /// <returns></returns>
        public string DisplayDate(DateTime dtDate)
        {
            if (dtDate != new DateTime(0))
                return dtDate.ToString(DATE_FORMAT);
            else
                return "";
        }
        #endregion

        #region Get Current Currency Culture
        /// <summary>
        /// Function use get the current currency culture from config file
        /// </summary>
        /// <returns></returns>
        public string GetCurrentCurrencyCulture()
        {
            string strCurrency;
            CultureInfo objCulture = new CultureInfo(System.Configuration.ConfigurationSettings.AppSettings["CurrentCurrencyCulture"].ToString());
            strCurrency = objCulture.NumberFormat.CurrencySymbol;

            return strCurrency;
        }
        #endregion

        #region Display Amount
        /// <summary>
        /// Function use to display the amount
        /// </summary>
        /// <param name="dcAmount"></param>
        /// <returns></returns>
        public string DisplayAmount(string dcAmount)
        {
            if (dcAmount != "")
            {
                string decAmt;
                string strCurrency = GetCurrentCurrencyCulture();
                decAmt = strCurrency + " " + Decimal.Parse(dcAmount.ToString(), System.Globalization.NumberStyles.Currency).ToString("N");
                return decAmt;
            }
            else
                return "";
        }
        #endregion

        #region Display Amount with two decimal only (without currency sign)
        /// <summary>
        /// Function use to display the amount
        /// </summary>
        /// <param name="dcAmount"></param>
        /// <returns></returns>
        public string DisplayAmount_withoutCurrency(string dcAmount)
        {
            if (dcAmount != "")
            {
                //return System.Configuration.ConfigurationSettings.AppSettings["CurrentCurrencySign"].ToString() + " " + Decimal.Parse(dcAmount.ToString(),System.Globalization.NumberStyles.Currency).ToString("N");
                string strCurrency = GetCurrentCurrencyCulture();
                //CultureInfo objCulture = new CultureInfo(System.Configuration.ConfigurationSettings.AppSettings["CurrentCurrencyCulture"].ToString());
                return strCurrency + " " + Decimal.Parse(dcAmount.ToString(), System.Globalization.NumberStyles.Currency).ToString("N");
            }
            else
                return "";
        }
        #endregion

        #region DisplayDateInCalendarTextBox
        /// <summary>
        /// Function use to Display the date in the Calendar Text box
        /// </summary>
        /// <param name="strDate"></param>
        /// <returns></returns>
        public string DisplayDateInCalendarTextBox(string strDate)
        {
            try
            {
                return DateTime.Parse(strDate).ToString(DATE_CALENDAR_FORMAT);
            }
            catch (Exception)
            {
                return "";
            }
        }
        #endregion

        #region ReturnDateToCurrentCulture
        /// <summary>
        /// Function use to read the Calendar Text box value into the DateTime object
        /// </summary>
        /// <param name="strDate"></param>
        /// <returns></returns>
        public string ReturnDateToCurrentCulture(string strDate)
        {
            strDate = strDate.Replace(DATE_SEPERATOR, "/");
            DateTime dt = FormatDate(strDate, DATE_CALENDAR_FORMAT);

            if (dt == DateTime.MinValue)
                return "";

            if (DERIVE_YEAR == true && dt != new DateTime(0))
            {
                int lintNewYear = 0;
                int lintYear = Int32.Parse(dt.Year.ToString().Substring(2, 2));
                if (lintYear >= 70)
                    lintNewYear = 1900 + lintYear;
                else
                    lintNewYear = 2000 + lintYear;
                dt = new DateTime(lintNewYear, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);
            }
            //return dt.ToString(CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern);
            return dt.ToString(DATE_CALENDAR_FORMAT);
        }
        #endregion

        #region AddQryStringToLink
        /// <summary>
        /// Function returns the Qrystring added to the url.
        /// </summary>
        /// <param name="strURL">URL</param>
        /// <param name="strQryString">Query String (Arg,value,..)</param>
        /// <returns>Qrystring added to the url</returns>
        public string AddQryStringToLink(string strURL, params string[] strQryStrings)
        {
            string strQryURL = strURL;
            for (int lintIndex = 0; lintIndex < strQryStrings.Length; lintIndex++)
            {
                if (lintIndex % 2 == 0)
                {
                    if (lintIndex == 0)
                        strQryURL += "?" + strQryStrings[lintIndex];
                    else
                        strQryURL += "&" + strQryStrings[lintIndex];
                }
                else
                    strQryURL += "=" + strQryStrings[lintIndex];
            }
            return strQryURL;
        }

        #endregion

        #region transform XML using XSLT
        /// <summary>
        /// transforms given input XML by applying the given XSL stylesheet and saves output in given file
        /// </summary>
        /// <param name="xslFile"></param>
        /// <param name="inputFile"></param>
        /// <param name="outputFile"></param>
        public void TransformXML(string xslFile, string inputFile, string outputFile)
        {
            //Create a new XslTransform object.
            XslTransform xslt = new XslTransform();

            //Load the stylesheet.
            xslt.Load(xslFile);

            //Create a new XPathDocument and load the XML data to be transformed.
            XPathDocument mydata = new XPathDocument(inputFile);

            //Create an XmlTextWriter which outputs to the given file
            XmlWriter writer = new XmlTextWriter(outputFile, System.Text.Encoding.UTF8);

            //Transform the data and send the output to the given file
            xslt.Transform(mydata, null, writer, new XmlUrlResolver());

            writer.Close();

        }

        #endregion

        #region WriteToFile
        /// <summary>
        /// writes given string in the given file
        /// </summary>
        /// <param name="data"></param>
        /// <param name="filename"></param>
        public void WriteToFile(string data, string filename)
        {
            //System.IO.StreamWriter objStreamWriter = new StreamWriter(File.Create(filename), System.Text.UnicodeEncoding.Unicode);
            System.IO.StreamWriter objStreamWriter = new StreamWriter(filename, false, UTF8Encoding.UTF8);
            objStreamWriter.Write(data);
            objStreamWriter.Close();
        }

        #endregion


        #region ReadFromUTF8File
        /// <summary>
        /// reads from given file and returns data in string
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public string ReadFromUTF8File(string filename)
        {
            System.IO.StreamReader objStreamReader = new StreamReader(filename, UTF8Encoding.UTF8);
            string strData = objStreamReader.ReadToEnd();
            objStreamReader.Close();
            return strData;

        }

        #endregion

        #region ReplaceNewLineWithParagraph
        /// <summary>
        /// replaces newline /r/n with paragraph <p></p>
        /// </summary>
        /// <param name="strInnerText"></param>
        /// <returns></returns>
        public string ReplaceNewLineWithParagraph(string strInnerText)
        {
            Regex regex = new Regex(@"<[^>]+>");
            if (!regex.IsMatch(strInnerText))
            {
                strInnerText = strInnerText.Replace("&nbsp;", " ");
                strInnerText = strInnerText.Replace("\r\n", "<br />");

                strInnerText = strInnerText.Replace("<p><p>", "<p>");
                strInnerText = strInnerText.Replace("</p></p>", "</p>");
                strInnerText = strInnerText.Replace("<BR>", "<br />");
                strInnerText = strInnerText.Replace("<br>", "<br />");
                if (!strInnerText.Trim().ToLower().StartsWith("<p>"))
                    strInnerText = "<p>" + strInnerText;

                if (!strInnerText.Trim().ToLower().EndsWith("</p>"))
                    strInnerText = strInnerText + "</p>";
            }
            strInnerText = strInnerText.Replace("<P>", "<p>");
            strInnerText = strInnerText.Replace("</P>", "</p>");

            return strInnerText;
        }

        #endregion

        #region	HEXA to NUMBER
        /// <summary>
        /// Convets Hexa decimal no to decimal number
        /// </summary>
        /// <param name="strHexaNumber">strHexaNumber</param>
        /// <returns>string</returns>
        public string HexaToNumber(string strHexaNumber)
        {
            strHexaNumber = strHexaNumber.ToUpper();
            if (strHexaNumber == "A" || strHexaNumber == "B" || strHexaNumber == "C" || strHexaNumber == "D" || strHexaNumber == "E" || strHexaNumber == "F")
            {
                if (strHexaNumber == "A")
                {
                    strHexaNumber = "10";
                }
                if (strHexaNumber == "B")
                {
                    strHexaNumber = "11";
                }
                if (strHexaNumber == "C")
                {
                    strHexaNumber = "12";
                }
                if (strHexaNumber == "D")
                {
                    strHexaNumber = "13";
                }
                if (strHexaNumber == "E")
                {
                    strHexaNumber = "14";
                }
                if (strHexaNumber == "F")
                {
                    strHexaNumber = "15";
                }
            }
            else
            {
                strHexaNumber = strHexaNumber;
            }
            return strHexaNumber;
        }
        #endregion

        #region GetCSVFromArray
        /// <summary>
        /// generates CSV from an integer array
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static string GetCSVFromArray(int[] arr)
        {
            string strCSV = "";
            for (int i = 0; i <= arr.Length - 1; i++)
                strCSV += "," + arr[i];
            if (strCSV != "")
                strCSV = strCSV.Remove(0, 1);
            return strCSV;
        }
        #endregion






    }
}
