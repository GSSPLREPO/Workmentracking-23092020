﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices.Common
{
    public class Class1
    {
    }
}
