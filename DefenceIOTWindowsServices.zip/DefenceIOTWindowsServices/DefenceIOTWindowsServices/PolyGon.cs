﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices
{
    class Point
    {
        public double X;
        public double Y;
    }
    class PolyGon
    {
        public List<Point> myPts = new List<Point>();
        public PolyGon()
        {
        }
        public PolyGon(List<Point> points)
        {
            foreach (Point p in points)
            {
                this.myPts.Add(p);
            }
        }
        public void Add(Point p)
        {
            this.myPts.Add(p);
        }
        public int Count()
        {
            return myPts.Count;
        }


        //  The function will return true if the point x,y is inside the polygon, or
        //  false if it is not.  If the point is exactly on the edge of the polygon,
        //  then the function may return true or false.

        public bool FindPoint(double X, double Y)
        {
            int sides = this.Count() - 1;
            int j = sides - 1;
            bool pointStatus = false;
            for (int i = 0; i < sides; i++)
            {
                if (myPts[i].Y < Y && myPts[j].Y >= Y || myPts[j].Y < Y && myPts[i].Y >= Y)
                {
                    if (myPts[i].X + (Y - myPts[i].Y) / (myPts[j].Y - myPts[i].Y) * (myPts[j].X - myPts[i].X) < X)
                    {
                        pointStatus = !pointStatus;
                    }
                }
                j = i;
            }
            return pointStatus;
        }
    }
}
