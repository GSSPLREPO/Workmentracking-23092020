﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefenceIOTWindowsServices
{
    class Payload
    {
        public int applicationID { get; set; }
        public string applicationName { get; set; }
        public string deviceName { get; set; }
        public string devEUI { get; set; }
        public List<RxInfo> rxInfo { get; set; }
        public TxInfo txInfo { get; set; }
        public string adr { get; set; }
        public int fcnt { get; set; }
        public int fport { get; set; }
        public string data { get; set; }
        [JsonProperty(PropertyName = "object")]
        public Objectdata objects { get; set; }
        public GeoLocation location { get; set; }
        
    }

    class RxInfo
    {
        public string gatewayID { get; set; }
        public string name { get; set; }
        public DateTime time { get; set; }
        public string rssi { get; set; }
        public string loRaSNR { get; set; }
        public Location location { get; set; }
    }

    class TxInfo
    {
        public string frequency { get; set; }
        public string dr { get; set; }

        public static implicit operator TxInfo(string v)
        {
            throw new NotImplementedException();
        }
    }


   public class Location
    {
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string altitude { get; set; }
        public string accuracy { get; set; }
        
    }

    class GeoLocation
    {
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string altitude { get; set; }
        public string accuracy { get; set; }
        public string x_data { get; set; }
        public string y_data { get; set; }
        public string n_data { get; set; }
    }
    class Objectdata
    {
        public string ALARM_status { get; set; }
        public string BatV { get; set; }
        public string GPSLock { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string Pitch { get; set; }
        public string Roll { get; set; }
        public string Yaw { get; set; }
        public string Sattelite { get; set; }
    }


    class Locationpayload
    {
        public string applicationID { get; set; }
        public string applicationName { get; set; }
        public string deviceName { get; set; }
        public string devEUI { get; set; }
        public Location location { get; set; }
    }

}
