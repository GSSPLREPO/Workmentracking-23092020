﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;
using Newtonsoft.Json;
using DefenceIOTWindowsServices.BO;
using DefenceIOTWindowsServices.Common;
using DefenceIOTWindowsServices.DataAccess;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading;
using DefenceIOTWindowsServices.BL;


namespace DefenceWS
{
    public partial class Service1 : ServiceBase
    {

        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        MqttClient client;


        string ClientId1 = (ConfigurationSettings.AppSettings["strClientID"]).ToString();
        string Url = (ConfigurationSettings.AppSettings["strUrl"]).ToString();
        int port = Convert.ToInt32((ConfigurationSettings.AppSettings["strPort"]).ToString());
        string connStr = (ConfigurationSettings.AppSettings["DBConnString"]).ToString();
        List<Point> points = new List<Point>();

        #region 
        public Service1()
        {
            //WriteToFile("Constructor for DefenceIOTWindows Service Called");
            InitializeComponent();
            //loadData();
            ServiceStart();
        }

        #region OnStart Method
        protected override void OnStart(string[] args)
        {
            //ServiceStart();
            log.Info("service started at" + DateTime.Now);
        }
        #endregion

        #region OnStop Method
        protected override void OnStop()
        {
            log.Info("On Stop Method");
        }
        #endregion

        #region ServiceStart
        public void ServiceStart()
        {
            try
            {

                //WriteToFile("Service Called");
                client = new MqttClient(Url, port, false, null, null, MqttSslProtocols.TLSv1_2, client_RemoteCertificateValidationCallback);

                string rt = Convert.ToString(Guid.NewGuid());
                string clientId = "apitest_" + rt.Substring(0, 6);

                reconnect:
                client.Connect(clientId);

                if (client.IsConnected == true)
                {
                    log.Info("mqtt client connected" + DateTime.Now);
                    client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

                    client.Subscribe(new string[] { "application/+/device/+/payload" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });

                }
                else
                {
                    goto reconnect;
                }

                //WriteToFile("Service Called completed");

            }
            catch (Exception ex)
            {
                log.Error("error in connection" + ex.Message);
                Console.Write(ex.Message, ex.Message);
                // Dispose(true);
                // Thread.Sleep(1000000);
                RestartService();

            }
        }
        #endregion


        #region Restart Service
        public static void RestartService()
        {
            ServiceController service = new ServiceController("DefenceIOTWS");
            try
            {
                int millisec1 = Environment.TickCount;
                TimeSpan timeout = TimeSpan.FromMilliseconds(100000);

                service.Stop();
                service.WaitForStatus(ServiceControllerStatus.Stopped, timeout);

                // count the rest of the timeout
                int millisec2 = Environment.TickCount;
                timeout = TimeSpan.FromMilliseconds(100000 - (millisec2 - millisec1));

                service.Start();
                service.WaitForStatus(ServiceControllerStatus.Running, timeout);
            }
            catch (Exception ex)
            {
                log.Error("Service not Restarted" + ex.Message); // ...
            }
        }

        #endregion

        #region client_MqttMsgPublishReceived
        public void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            bool isout = true;
            log.Info("topic recived" + Encoding.UTF8.GetString(e.Message));
            try
            {
                //WriteToFile("Mqtt Subscribe Started");
                string strReceivedMessage = Encoding.UTF8.GetString(e.Message);
                JObject json = JObject.Parse(strReceivedMessage);

                var result = JsonConvert.DeserializeObject<Payload>(strReceivedMessage);

                var datac = Convert.FromBase64String(result.data);
                var paydata = ByteArrayToString(datac);

                var pcount = paydata.Length;
                var dataflag = paydata.Substring(0, 2);

                DefenceIOTWindowsServices.BO.PayloadData pdata = new PayloadData();
                pdata.applicationID = result.applicationID;
                pdata.applicationName = result.applicationName;
                pdata.deviceName = result.deviceName;
                pdata.devEUI = result.devEUI;
                pdata.rxInfo = JsonConvert.SerializeObject(result.rxInfo);
                pdata.adr = "";
                pdata.fcnt = result.fcnt;
                pdata.fport = result.fport;
                pdata.data = JsonConvert.SerializeObject(result);
                pdata.txInfo = "";
                pdata.objects = result.ToString();
                pdata.x_data = result.location.x_data;
                pdata.y_data = result.location.y_data;
                pdata.n_data = result.location.n_data;
                pdata.location = JsonConvert.SerializeObject(result.location);

                DefenceIOTWindowsServices.BL.TagDataInsertBL tgbl1 = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                ApplicationResult apresult1 = new ApplicationResult();
                apresult1 = tgbl1.Payload_Insert(pdata);
                Console.Write(apresult1);

                //sls debug logS

                DefenceIOTWindowsServices.BO.locationxy xydata = new locationxy();
                xydata.devicename = result.deviceName;
                xydata.deveui = result.devEUI;
                xydata.xdata = result.location.x_data;
                xydata.ydata = result.location.y_data;
                xydata.ndata = result.location.n_data;
                xydata.logdate = result.rxInfo[0].time;
                xydata.IsPayload = dataflag;

                DefenceIOTWindowsServices.BL.TagDataInsertBL locxy = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                ApplicationResult appxy = new ApplicationResult();
                appxy = locxy.locationxy_Insert(xydata);
                Console.Write(appxy);

                var len = paydata.Length;


                if (dataflag == "01")
                {

                    if (len != 70)
                    {
                        log.Info("data have unknown bytes" + paydata);
                    }
                    else
                    {

                        if (result.rxInfo.Count > 0)
                        {
                        }
                        foreach (var item in result.rxInfo)
                        {
                            DefenceIOTWindowsServices.BO.gatwaymeta gtm = new gatwaymeta();
                            gtm.DeviceName = result.deviceName;
                            gtm.DeviceMac = result.devEUI;
                            gtm.gateway_name = item.name;
                            gtm.gateway_mac = item.gatewayID;
                            gtm.rssi = item.rssi;
                            gtm.snr = item.loRaSNR;
                            gtm.alert = false;
                            gtm.logdate = item.time;
                            var rssi = int.Parse(item.rssi);
                            var gpslock = int.Parse(paydata.Substring(2, 2));
                            if (gpslock > 0 && rssi > -55)
                            {
                                isout = false;
                            }

                            DefenceIOTWindowsServices.BL.TagDataInsertBL gtmxy = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                            ApplicationResult appgtmxy = new ApplicationResult();
                            appxy = locxy.gatewaymeta_Insert(gtm);
                            Console.Write(appgtmxy);

                        }

                        double finallat, finallon;
                        int ltn = 10000;


                        int divider = 1000;
                        int rpt = 100;
                        if (result.location != null)
                        {
                            var gpslock = paydata.Substring(2, 2);
                            var satelitecount = int.Parse(paydata.Substring(4, 2));
                            if (satelitecount < 4)
                            {
                                finallat = double.Parse(result.location.latitude);
                                finallon = double.Parse(result.location.longitude);
                            }
                            else
                            {
                                var Latitude = paydata.Substring(6, 6);
                                var decimlat = int.Parse(Latitude, System.Globalization.NumberStyles.HexNumber);
                                finallat = (double)decimlat / (double)ltn;
                                var logitude = paydata.Substring(12, 6);
                                var decimlon = int.Parse(logitude, System.Globalization.NumberStyles.HexNumber);
                                finallon = (double)decimlon / (double)ltn;
                            }



                            var AlarmABat = paydata.Substring(18, 4);
                            var decbat = int.Parse(AlarmABat, System.Globalization.NumberStyles.HexNumber);
                            double finalbat = ((double)decbat / (double)divider);

                            var pitch = paydata.Substring(22, 4);
                            var finalpit = int.Parse(pitch, System.Globalization.NumberStyles.HexNumber);
                            double pit = (double)finalpit / (double)rpt;
                            var Roll = paydata.Substring(26, 4);
                            var finalrll = int.Parse(Roll, System.Globalization.NumberStyles.HexNumber);
                            double rl = (double)finalrll / (double)rpt;

                            //update at 11-09-2019
                            var yaw = paydata.Substring(30, 4);
                            var finalyaw = int.Parse(yaw, System.Globalization.NumberStyles.HexNumber);
                            double yw = (double)finalyaw / (double)rpt; ;

                            var acax = paydata.Substring(34, 4);
                            var acay = paydata.Substring(38, 4);
                            var acaz = paydata.Substring(42, 4);
                            var gax = paydata.Substring(46, 4);
                            var gay = paydata.Substring(50, 4);
                            var gaz = paydata.Substring(54, 4);
                            var mx = paydata.Substring(58, 4);
                            var my = paydata.Substring(62, 4);
                            var mz = paydata.Substring(66, 4);


                            var facax = uint.Parse(acax, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fcx = (double)facax / 1000000;
                            var facay = uint.Parse(acay, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fcy = (double)facay / 1000000;
                            var facaz = uint.Parse(acaz, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fcz = (double)facaz / 1000000;



                            var fgax = uint.Parse(gax, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fgcx = (double)fgax / 1000000;
                            var fgay = uint.Parse(gay, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fgcy = (double)fgay / 1000000;
                            var fgaz = uint.Parse(gaz, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fgcz = (double)fgaz / 1000000;


                            var fmx = uint.Parse(mx, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fmcx = (double)fmx / 1000000;
                            var fmy = uint.Parse(my, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fmcy = (double)fmy / 1000000;
                            var fmz = uint.Parse(mz, System.Globalization.NumberStyles.AllowHexSpecifier);
                            double fmcz = (double)fmz / 1000000;

                            DefenceIOTWindowsServices.BO.Payload pd = new DefenceIOTWindowsServices.BO.Payload();

                            pd.DeviceEUI = result.devEUI.ToString();
                            pd.Gpslock = Convert.ToInt32(gpslock);
                            pd.SateliteCount = satelitecount;
                            pd.Latitude = finallat.ToString();
                            pd.Longitude = finallon.ToString();
                            pd.Alarm = AlarmABat;
                            pd.Battery = finalbat.ToString();
                            pd.Pitch = pit.ToString();
                            pd.Roll = rl.ToString();
                            pd.payload = result.data.ToString();
                            pd.yaw = yw.ToString();

                            pd.acax = fcx.ToString();
                            pd.acay = fcy.ToString();
                            pd.acaz = fcz.ToString();

                            pd.gx = fgcx.ToString();

                            pd.gy = fgcy.ToString();
                            pd.gz = fgcz.ToString();

                            pd.mx = fmcx.ToString();
                            pd.my = fmcy.ToString();
                            pd.mz = fmcz.ToString();

                            pd.Isout = isout;

                            DefenceIOTWindowsServices.BL.TagDataInsertBL tgl = new DefenceIOTWindowsServices.BL.TagDataInsertBL();

                            ApplicationResult resultdata = new ApplicationResult();
                            resultdata = tgl.PayloadData_Insert(pd);
                            Console.Write(resultdata);


                        }


                    }

                }
                else
                {
                    var alertCode = paydata.Substring(2, 2);
                    var alertType = paydata.Substring(4, 2);
                    var alertPriority = paydata.Substring(6, 2);
                    int alertCounter = 0;

                    if (alertCode.ToLower() == "0c")
                    {
                        alertCounter = 1;
                    }
                    else
                    {
                        alertCounter = 1;
                    }
                    var account = int.Parse(paydata.Substring(8, 4), System.Globalization.NumberStyles.HexNumber);
                    string acxl, acxh, acyl, acyh, aczl, aczh, acc1, acc2, acc3 = "";
                    if (alertCode.ToLower() == "0a")
                    {

                        var tacxl = int.Parse(paydata.Substring(12, 2), System.Globalization.NumberStyles.HexNumber);
                        acxl = tacxl.ToString();
                        var tacxh = int.Parse(paydata.Substring(14, 2), System.Globalization.NumberStyles.HexNumber);
                        acxh = tacxh.ToString();
                        var tacyl = int.Parse(paydata.Substring(16, 2), System.Globalization.NumberStyles.HexNumber);
                        acyl = tacyl.ToString();
                        var tacyh = int.Parse(paydata.Substring(18, 2), System.Globalization.NumberStyles.HexNumber);
                        acyh = tacyh.ToString();
                        var taczl = int.Parse(paydata.Substring(20, 2), System.Globalization.NumberStyles.HexNumber);
                        aczl = tacyl.ToString();
                        var taczh = int.Parse(paydata.Substring(22, 2), System.Globalization.NumberStyles.HexNumber);
                        aczh = tacyh.ToString();




                        DefenceIOTWindowsServices.BO.PayloadAlert pa = new PayloadAlert();
                        pa.DeviceEUI = result.devEUI.ToString();
                        pa.AlertCode = alertCode;
                        pa.AlertType = alertType;
                        pa.AlertPriority = alertPriority;
                        pa.AlertCounter = account.ToString();
                        pa.AcXL = acxl;
                        pa.AcXH = acxh;
                        pa.AcYL = acyl;
                        pa.AcYH = acyh;
                        pa.AcZL = aczl;
                        pa.AcZH = aczh;
                        pa.Acc1 = "";
                        pa.Acc2 = "";
                        pa.Acc3 = "";
                        pa.Latitude = result.location.latitude.ToString();
                        pa.Longitude = result.location.longitude.ToString();
                        DefenceIOTWindowsServices.BL.TagDataInsertBL tgbl = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                        ApplicationResult apresult = new ApplicationResult();
                        apresult = tgbl.PayloadAlert_Insert(pa);
                        Console.Write(result);


                    }
                    else if (alertCode.ToLower() == "0b")
                    {
                        acc1 = paydata.Substring(12, 2);

                        DefenceIOTWindowsServices.BO.PayloadAlert pa = new PayloadAlert();
                        pa.DeviceEUI = result.devEUI.ToString();
                        pa.AlertCode = alertCode;
                        pa.AlertType = alertType;
                        pa.AlertPriority = alertPriority;
                        pa.AlertCounter = account.ToString();
                        pa.AcXL = "";
                        pa.AcXH = "";
                        pa.AcYL = "";
                        pa.AcYH = "";
                        pa.AcZL = "";
                        pa.AcZH = "";
                        pa.Acc1 = acc1;
                        pa.Acc2 = "";
                        pa.Acc3 = "";
                        pa.Latitude = result.location.latitude.ToString();
                        pa.Longitude = result.location.longitude.ToString();
                        DefenceIOTWindowsServices.BL.TagDataInsertBL tgbl = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                        ApplicationResult apresult = new ApplicationResult();
                        apresult = tgbl.PayloadAlert_Insert(pa);
                        Console.Write(result);



                    }
                    else if (alertCode.ToLower() == "0d")
                    {
                        acc2 = paydata.Substring(12, 2);

                        DefenceIOTWindowsServices.BO.PayloadAlert pa = new PayloadAlert();
                        pa.DeviceEUI = result.devEUI.ToString();
                        pa.AlertCode = alertCode;
                        pa.AlertType = alertType;
                        pa.AlertPriority = alertPriority;
                        pa.AlertCounter = account.ToString();
                        pa.AcXL = "";
                        pa.AcXH = "";
                        pa.AcYL = "";
                        pa.AcYH = "";
                        pa.AcZL = "";
                        pa.AcZH = "";
                        pa.Acc1 = "";
                        pa.Acc2 = acc2;
                        pa.Acc3 = "";
                        pa.Latitude = result.location.latitude.ToString();
                        pa.Longitude = result.location.longitude.ToString();
                        DefenceIOTWindowsServices.BL.TagDataInsertBL tgbl = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                        ApplicationResult apresult = new ApplicationResult();
                        apresult = tgbl.PayloadAlert_Insert(pa);
                        Console.Write(result);



                    }
                    else if (alertCode == "0c")
                    {
                        // acc3 = paydata.Substring(12, 2);

                        DefenceIOTWindowsServices.BO.PayloadAlert pa = new PayloadAlert();
                        pa.DeviceEUI = result.devEUI.ToString();
                        pa.AlertCode = alertCode;
                        pa.AlertType = alertType;
                        pa.AlertPriority = alertPriority;
                        pa.AlertCounter = account.ToString();
                        pa.AcXL = "";
                        pa.AcXH = "";
                        pa.AcYL = "";
                        pa.AcYH = "";
                        pa.AcZL = "";
                        pa.AcZH = "";
                        pa.Acc1 = "";
                        pa.Acc2 = "";
                        pa.Acc3 = acc3;
                        pa.Latitude = result.location.latitude.ToString();
                        pa.Longitude = result.location.longitude.ToString();
                        DefenceIOTWindowsServices.BL.TagDataInsertBL tgbl = new DefenceIOTWindowsServices.BL.TagDataInsertBL();
                        ApplicationResult apresult = new ApplicationResult();
                        apresult = tgbl.PayloadAlert_Insert(pa);
                        Console.Write(result);

                    }


                }

                //WriteToFile("Mqtt Subscribe completed");

            }
            catch (Exception ex)
            {
                log.Error("Mqtt services have issue" + ex.Message + Encoding.UTF8.GetString(e.Message));
                RestartService();
            }

        }
        #endregion

        private bool client_RemoteCertificateValidationCallback(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }


        // load  polygon points from the XML
        #region LoadData
        private void loadData()
        {
            //WriteToFile("LoadData  Started");
            try
            {
                DataSet ds = new DataSet();
                ds.ReadXml("PolygonPoints.XML");
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Point p = new Point();
                    String Lat = dr[0].ToString();
                    p.X = Double.Parse(Lat);
                    String Long = dr[1].ToString();
                    p.Y = Double.Parse(Long);
                    points.Add(p);
                }
            }
            catch (Exception ex)
            {

                //WriteToFile("LoadData  Stopped" + ex.Message);
            }
            //WriteToFile("LoadData  Stopped");
        }
        #endregion

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        #region Write To Txt File

        private void WriteToFile(string text)
        {
            string path = "C:\\Users\\Public\\LoraDataReceived.txt";
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine(string.Format(text + " " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt")));
                writer.Close();

            }
        }
        #endregion

    }
}
#endregion